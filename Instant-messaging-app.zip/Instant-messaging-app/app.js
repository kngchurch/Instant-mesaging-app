const express = require('express');
const dotenv = require('dotenv');
const userRoutes = require('./routes/userRoutes');